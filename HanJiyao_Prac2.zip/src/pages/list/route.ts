import { Component, OnInit, ViewChild, ElementRef, NgZone } from
'@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { ParkService } from '../../providers/parkservice';
import { Park } from '../../models/park'; 


declare var google;
@Component({
  selector: 'page-route',
  templateUrl: 'route.html'
})
export class RoutePage {
  @ViewChild('map') mapElement: ElementRef;
  map: any;
  results: string[];

  parks:Park[];
  
  private markers = [];
  private directionsService = new google.maps.DirectionsService();
  private directionsDisplay = new google.maps.DirectionsRenderer({
  map: this.map,
  suppressMarkers: true,
  preserveViewport: true
  });

  private start;
  private end;
  private waypts = [];

  constructor(
    public navCtrl: NavController, 
    public geolocation: Geolocation,
    private parkService: ParkService, public navParams: NavParams,
    private zone: NgZone,
  ){
  }
  ionViewDidLoad(){
    console.log("ionview did load");
    this.loadMap();
  }
  loadMap(){
    this.geolocation.getCurrentPosition().then((position) => {
      let latLng = new google.maps.LatLng(1.3786539, 103.8493234);
      let mapOptions = {
      center: latLng,
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    }, (err) => {
      console.log(err);
    });
    

    let parkData = [];
    this.parkService.getLocalData().subscribe(results => {
      this.results = results
      for (let i = 0; i < results.length; i++) {
        let coords = results[i];
        console.log(coords.lat, coords.long)
        let latLng = new google.maps.LatLng(coords.lat, coords.long);
        parkData.push(latLng);
        // this.addMarker(latLng, coords)
        //this.parks.push(new Park(coords.school))
      }
    });

      this.directionsDisplay.addListener('direction_changed', function(){
    this.computeTotalDistance(this.directionsDisplay.getDirections())
  })
  }

  displayRoute(){
//validation 
if (parks == undefined){
 alert("need to have start and end point")
}

    this.directionsService = new google.maps.DirectionsService()
    this.directionsDisplay = new google.maps.DirectionsRenderer()
    this.directionsDisplay.setMap(this.map)
    this.directionsService.route({
    // origin: this.start,
    // destination: this.end,
    origin: new google.maps.LatLng(1.3786539, 103.8493234),
    destination: new google.maps.LatLng(1.3634088, 103.8435614),
    travelMode: 'DRIVING'
   }, (response, status) => {
    if (status === 'OK') {
    this.directionsDisplay.setDirections(response)
    } else {
    window.alert('Directions request failed due to ' + status)
    }
    })
   }

   computeTotalDistance(result) {
     var total = 0;
     var myroute = result.routes[0]
     for (var i = 0;i<myroute.legs.length;i++){
       total+=myroute.legs[i].distance.value;
     }
     total = total/1000
     document.getElementById('total').innerHTML = total+'km'
   }

   clearMarkers(){
     console.log("clear")

   }
}