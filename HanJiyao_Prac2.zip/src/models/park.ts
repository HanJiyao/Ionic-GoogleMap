export class Park {

    constructor(
    public place: string
    ) { }
   
    }